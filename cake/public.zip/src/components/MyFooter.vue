<template>
  <div>
    <div>
      <mt-tabbar fixed>
        <mt-tab-item id="message">首页</mt-tab-item>
        <mt-tab-item id="contacts">分类</mt-tab-item>
        <mt-tab-item id="find">购物车</mt-tab-item>
        <mt-tab-item id="me">个人中心</mt-tab-item>
      </mt-tabbar>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>

